# Godot-Roguelike-Tutorial
A series of videos on how to make a roguelike using the Godot game engine: https://www.youtube.com/playlist?list=PL2-ArCpIQtjELkyLKec8BaVVCeunuHSK9

Play the game on itch.io: https://mateu-s.itch.io/godot-roguelike-tutorial

![Spikes](Screenshots/spikes.png)

![Charged attack](Screenshots/charged_attack.png)
